# dj-commented-view

A package written for PCTNet that provides mixins for Django single-object class based views annotated by other objects.

# Classes
## CommentBaseMixin
## CommentListMixin
## CommentPostMixin

